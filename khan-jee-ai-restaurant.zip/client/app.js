
const API = "http://localhost:5000";

async function login(){
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const res = await fetch(API+"/login",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({email,password})
  });

  const data = await res.json();

  if(data.role === "admin"){
    window.location.href="admin.html";
  }else{
    window.location.href="customer.html";
  }
}

async function loadMenu(){
  const res = await fetch(API+"/menu");
  const data = await res.json();

  const div = document.getElementById("menu");
  if(div){
    div.innerHTML = data.map(i=>`<p>${i.name} - RM${i.price}</p>`).join("");
  }
}

async function chat(){
  const msg = document.getElementById("msg").value;

  const res = await fetch(API+"/chat",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({message:msg})
  });

  const data = await res.json();

  document.getElementById("chat").innerHTML += 
  "<p><b>You:</b> "+msg+"</p><p><b>AI:</b> "+data.reply+"</p>";
}

async function loadOrders(){
  const res = await fetch(API+"/orders");
  const data = await res.json();

  const div = document.getElementById("orders");
  if(div){
    div.innerHTML = JSON.stringify(data);
  }
}

loadMenu();
loadOrders();
