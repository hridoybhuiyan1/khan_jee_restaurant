
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET = "secret123";

let users = [
  { id: 1, email: "admin@khanjee.com", password: "admin123", role: "admin" },
  { id: 2, email: "user@khanjee.com", password: "user123", role: "customer" }
];

let menu = [
  { id: 1, name: "Chicken Biryani", price: 18.9 },
  { id: 2, name: "Mutton Karahi", price: 45.9 }
];

let orders = [];

// LOGIN
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return res.json({ error: "Invalid login" });

  const token = jwt.sign({ id: user.id, role: user.role }, SECRET);

  res.json({ token, role: user.role });
});

// MENU
app.get("/menu", (req, res) => {
  res.json(menu);
});

// ORDER
app.post("/order", (req, res) => {
  const { items } = req.body;
  orders.push({ id: orders.length + 1, items });
  res.json({ message: "Order placed" });
});

// ADMIN ORDERS
app.get("/orders", (req, res) => {
  res.json(orders);
});

// CHATBOT
app.post("/chat", (req, res) => {
  const msg = req.body.message.toLowerCase();

  if (msg.includes("biryani")) return res.json({ reply: "Chicken Biryani RM18.90" });
  if (msg.includes("karahi")) return res.json({ reply: "Mutton Karahi RM45.90" });

  res.json({ reply: "Welcome to Khan Jee Restaurant" });
});

app.listen(5000, () => console.log("Server running on 5000"));
